﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Play : MonoBehaviour {

	RectTransform scrollValue1;
	RectTransform scrollValue2;
	RectTransform scrollValue3;
	float f1;
	float f2;
	float f3;
	bool isPlaying;

	public Image[] bttn;
	private int bttnLength;
	public RectTransform centerLine;
	string[] disToCenter;
	
	int j;
	public GameObject winMessage;
	public bool flag;
	public bool hasStopped;

	public GameObject gScoreText;
	public GameObject betText;

	// Use this for initialization
	void Start () {
		Database.Instance = new Database ();
		scrollValue1 = GameObject.Find ("Scroll1").GetComponent<RectTransform> ();
		scrollValue2 = GameObject.Find ("Scroll2").GetComponent<RectTransform> ();
		scrollValue3 = GameObject.Find ("Scroll3").GetComponent<RectTransform> ();
		f1 = 0.8f;
		f2 = 0.8f;
		f3 = 0.8f;

		isPlaying = false;
		scrollValue1.pivot = new Vector2(0.5f,f1);
		scrollValue2.pivot = new Vector2(0.5f,f2);
		scrollValue3.pivot = new Vector2(0.5f,f3);
		bttnLength = bttn.Length;
		disToCenter = new string[3];

		flag = true;
		hasStopped = false;

		gScoreText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Watermelons: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.score+"</b></color></size>";
		betText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Bets: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.bet+"</b></color></size>";
	}
	
	// Update is called once per frame
	void Update () {

		//if click play button
		if (isPlaying) {
			//decrease the scroll speed 
			if (f1 > 0.8f) {
				f1 -= 0.1f * Time.deltaTime;
				scrollValue1.pivot = new Vector2 (0.5f, f1);
			} else {
				f1 = 0.8f;
			}

			if (f2 >= 0.8f) {
				f2 -= 0.1f * Time.deltaTime;
				scrollValue2.pivot = new Vector2 (0.5f, f2);
			} else {
				f2 = 0.8f;
			}

			if (f3 >= 0.8f) {
				f3 -= 0.1f * Time.deltaTime;
				scrollValue3.pivot = new Vector2 (0.5f, f3);
			} else {
				f3 = 0.8f;
			}

			//if the scroll bar stops
			if (f1 <= 0.8f && f2 <= 0.8f && f3 <= 0.8f) 
			{
				hasStopped = true;
				flag = true;
				j = 0;
				//get all the buttons and extract the three that stops on the line
				for (int i=0; i<bttnLength; i++) {
					float diff = bttn [i].GetComponent<RectTransform> ().position.y - centerLine.GetComponent<RectTransform> ().position.y;
					if (0 < diff && diff < 25) {
						disToCenter [j] = bttn [i].tag;
						j++;
					}
				}

				//check the tag of the image and increase score of it
				for (int i = 0; i<j-1; i++) {
					if (disToCenter [i] != disToCenter [i + 1]) {
						flag = false;
					}
				}
				isPlaying = false;

			}
		}
		else 
		{	
			if (hasStopped) 
			{
				if (flag == true) {
					Database.Instance.score += Database.Instance.bet;
				}
				else
				{
					Database.Instance.score -= Database.Instance.bet;
				}

				if(Database.Instance.score<0)
				{
					winMessage.SetActive (true);
					Database.Instance.score = 10;
					Database.Instance.bet = 1;
					Database.Instance.betText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Bets: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.bet+"</b></color></size>";
				} 

				gScoreText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Watermelons: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.score+"</b></color></size>";

				hasStopped = false;
			} 
		}
	}

	public void begin()
	{
		winMessage.SetActive (false);
		isPlaying = true;
		f1 = Random.Range (1.5f,2.5f);
		f2 = Random.Range (1.5f,2.5f);
		f3 = Random.Range (1.5f,2.5f);

	}
	
}
