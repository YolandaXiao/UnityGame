﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Bet : MonoBehaviour 
{
	public void increaseBet()
	{
		Database.Instance.bet += 1;
		Database.Instance.betText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Bets: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.bet+"</b></color></size>";
	}

	public void decreaseBet()
	{
		if (Database.Instance.bet > 1) 
		{
			Database.Instance.bet -= 1;
			Database.Instance.betText.GetComponent<Text> ().text = "<size=25><color=#fff8dc><b>#Bets: </b></color></size>" + "<size=40><color=#fff8dc><b>"+Database.Instance.bet+"</b></color></size>";
		}
	}
}
