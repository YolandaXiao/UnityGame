﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScrollSlot: MonoBehaviour {
	public RectTransform panel; //to hold the scrollpanel
	public Image[] bttn;
	public RectTransform center;//center to compare the distance for each button
	
	public float[] distance; //all buttons' distance to the center
	public float[] disReposition;
	private bool dragging = false; //wiill be true if we drag the panel
	private int bttnDistance; // will hold the distance between the buttons
	private int minButtonNum; //the number of the button with smallest distance
	private int bttnLength;

	//public float[] finalImages;
	
	void Start()
	{
		bttnLength = bttn.Length;
		distance = new float[bttnLength];
		disReposition = new float[bttnLength];
		
		//get distance between buttons
		bttnDistance = (int)Mathf.Abs (bttn[1].GetComponent<RectTransform>().anchoredPosition.y - bttn [0].GetComponent<RectTransform> ().anchoredPosition.y);
	}
	
	void Update()
	{
		for(int i = 0; i < bttn.Length; i++)
		{
			disReposition[i] = center.GetComponent<RectTransform>().position.y - bttn[i].GetComponent<RectTransform>().position.y;
			distance[i] = Mathf.Abs(disReposition[i]);

			if(disReposition[i] > 125)
			{
				float curX = bttn[i].GetComponent<RectTransform>().anchoredPosition.x;
				float curY = bttn[i].GetComponent<RectTransform>().anchoredPosition.y;

				Vector2 newAnchoredPos = new Vector2 (curX,curY + (bttnLength*bttnDistance));
				bttn[i].GetComponent<RectTransform>().anchoredPosition = newAnchoredPos;
			}
		}

		float minDistance = Mathf.Min (distance);

		for(int a = 0; a < bttn.Length; a++)
		{
			if(minDistance == distance[a])
			{
				minButtonNum = a;
			}
		}
		if (!dragging) 
		{
			//LerpToBttn(minButtonNum* -bttnDistance);
			LerpToBttn(-bttn[minButtonNum].GetComponent<RectTransform>().anchoredPosition.y);
		}

	}

	void LerpToBttn(float position)
	{
		float newY = Mathf.Lerp (panel.anchoredPosition.y, position, Time.deltaTime * 2f);
		Vector2 newPosition = new Vector2 ( panel.anchoredPosition.x, newY);

		panel.anchoredPosition = newPosition;

	}

	public void StartDrag()
	{
		dragging = true;
	}

	public void EngDrag()
	{
		dragging = false;
	}
	
	
}