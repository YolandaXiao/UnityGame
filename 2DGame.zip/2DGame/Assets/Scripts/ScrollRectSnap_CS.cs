﻿/*using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ScrollRectSnap_CS : MonoBehaviour {
	public RectTransform panel; //to hold the scrollpanel
	public Button[] bttn;
	public RectTransform center;//center to compare the distance for each button

	private float[] distance; //all buttons' distance to the center
	private bool dragging = false; //wiill be true if we drag the panel
	private int bttnDistance; // will hold the distance between the buttons
	private int minButtonNum; //the number of the button with smallest distance

	void Start()
	{
		int bttnLength = bttn.Length;
		distance = new float[bttnLength];

		//get distance between buttons
		bttnDistance = (int)Mathf.Abs (bttn[1].GetComponent<RectTransform>().anchoredPosition.x - bttn [0].GetComponent<RectTransform> ().anchoredPosition.x);
	}

	void Update()
	{
		for(int i = 0; i < bttn.Length; i++)
		{
			distance[i] = Mathf.Abs(center.transform.position.x - bttn[i].transform.position.x);
		}
	}



}
*/