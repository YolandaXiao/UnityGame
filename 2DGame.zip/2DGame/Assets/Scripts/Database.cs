﻿using UnityEngine;
using System.Collections;

public class Database{
	public static Database Instance;

	public GameObject betText;

	public int bet;
	public int score;
	
	public Database () 
	{
		Instance = this;
		betText = GameObject.Find ("BetDisplay");
		score = 10;
		bet = 1;
	}
}
